import discord
from discord.ext import commands
import asyncio
import datetime
import os
from discord.ui import View

class Responder(commands.Cog):
  def __init__(self, bot):
      self.bot = bot

  @commands.Cog.listener()
  async def on_message(self, message):
     if message.author.bot:
        return
     if message.content.startswith("$help"):
         button = discord.ui.Button(label="Support Server",
                               style=discord.ButtonStyle.link,
                               url="https://discord.gg/h6q2H3ZscF")
          button2 = discord.ui.Button(
        label="Invite Me",
        style=discord.ButtonStyle.link,
        url=
        f"https://discord.com/api/oauth2/authorize?client_id={self.bot.user.id}"
    )
          button3 = discord.ui.Button(
        label=f"Guilds: {len(self.bot.guilds)}", disabled=True)
          button4 = discord.ui.Button(label=f"Users: {len(self.bot.users)}",
                                disabled=True)

          view = discord.ui.View()
          view.add_item(button)
          view.add_item(button2)
          view.add_item(button3)
          view.add_item(button4)

          await message.channel.send(
        f"Hello {message.author.mention}! My prefix is `p!` If you need any help please click on one of the buttons below!",
        view=view)

def setup(bot):
  bot.add_cog(Responder(bot))
       