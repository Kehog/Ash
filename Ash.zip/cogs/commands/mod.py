import discord
from discord.commands.options import Option
from discord.ext import commands
import asyncio
import datetime
import os
from discord.commands.core import slash_command

class Mod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(description="Warns a member")
    async def warn(self, ctx, member: Option(discord.Member, "The member to warn"), reason: Option(str, "The reason for the warn")):
        if ctx.author.guild_permissions.moderate_members:
            await ctx.respond(f"**☑ Success** | Warned {member.mention} for {reason}")

            emb = discord.Embed(title=f"Warned - {member}", description=f"**Reason:** {reason}", color=discord.Color.red())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Unwarns a member")
    async def unwarn(self, ctx, member: Option(discord.Member, "The member to unwarn"), reason: Option(str, "The reason for the unwarn")):
        if ctx.author.guild_permissions.moderate_members:
            await ctx.respond(f"**☑ Success** | Unwarned {member.mention} for {reason}")

            emb = discord.Embed(title=f"Unwarned - {member}", description=f"**Reason:** {reason}", color=discord.Color.green())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Kicks a member")
    async def kick(self, ctx, member: Option(discord.Member, "The member to kick"), reason: Option(str, "The reason for the kick")):
        if ctx.author.guild_permissions.kick_members:
            await ctx.respond(f"**☑ Success** | Kicked {member.mention} for {reason}")

            emb = discord.Embed(title=f"Kicked - {member}", description=f"**Reason:** {reason}", color=discord.Color.red())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)
            await member.kick(reason=reason)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Bans a member")
    async def ban(self, ctx, member: Option(discord.Member, "The member to ban"), reason: Option(str, "The reason for the ban")):
        if ctx.author.guild_permissions.ban_members:
            await ctx.respond(f"**☑ Success** | Banned {member.mention} for {reason}")

            emb = discord.Embed(title=f"Banned - {member}", description=f"**Reason:** {reason}", color=discord.Color.red())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)
            await member.ban(reason=reason)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Unbans a member")
    async def unban(self, ctx, member: Option(discord.Member, "The member to unban"), reason: Option(str, "The reason for the unban")):
        if ctx.author.guild_permissions.ban_members:
            await ctx.respond(f"**☑ Success** | Unbanned {member.mention} for {reason}")

            emb = discord.Embed(title=f"Unbanned - {member}", description=f"**Reason:** {reason}", color=discord.Color.red())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)
            await member.unban(reason=reason)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Soft bans a member")
    async def softban(self, ctx, member: Option(discord.Member, "The member to softban"), reason: Option(str, "The reason for the softban")):
        if ctx.author.guild_permissions.ban_members:
            await ctx.respond(f"**☑ Success** | Soft banned {member.mention} for {reason}")

            emb = discord.Embed(title=f"Soft banned - {member}", description=f"**Reason:** {reason}", color=discord.Color.red())
            emb.add_field(name="**User:**", value=member)
            emb.add_field(name="**Moderator:**", value=ctx.author)
            emb.add_field(name="**Reason:**", value=reason)
            emb.add_field(name="**Guild:**", value=ctx.guild.name)
            emb.set_author(name=ctx.author, icon_url=ctx.author.avatar.url)
            emb.set_thumbnail(url=ctx.author.avatar.url)
            emb.set_footer(text=f"ID: {member.id}")
            emb.timestamp = datetime.datetime.utcnow()
            await member.send(embed=emb)
            await member.ban(reason=reason)
            await asyncio.sleep(1)
            await member.unban(reason=reason)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Mutes a member")
    async def mute(self, ctx, member: Option(discord.Member, "The member to mute"), reason: Option(str, "The reason for the mute"), time: Option(int, "The time for the mute (Seconds only)")):
        if ctx.author.guild_permissions.moderate_members:
            await ctx.respond(f"**☑ Success** | Muted {member.mention} for {reason}")

            await member.time_out(reason=reason, duration=time)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Unmutes a member")
    async def unmute(self, ctx, member: Option(discord.Member, "The member to unmute"), reason: Option(str, "The reason for the unmute")):
        if ctx.author.guild_permissions.moderate_members:
            await ctx.respond(f"**☑ Success** | Unmuted {member.mention} for {reason}")

            await member.time_out(reason=reason, duration=None)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Locks a channel")
    async def lock(self, ctx, channel: Option(discord.TextChannel, "The channel to lock")):
        if ctx.author.guild_permissions.manage_channels:
            await ctx.respond(f"**☑ Success** | Locked {channel.mention}")
            await channel.set_permissions(ctx.guild.default_role, send_messages=False)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Unlocks a channel")
    async def unlock(self, ctx, channel: Option(discord.TextChannel, "The channel to unlock")):
        if ctx.author.guild_permissions.manage_channels:
            await ctx.respond(f"**☑ Success** | Unlocked {channel.mention}")
            await channel.set_permissions(ctx.guild.default_role, send_messages=True)

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

    @slash_command(description="Purges x amount of messages")
    async def purge(self, ctx, amount: Option(int, "The amount of messages to delete")):
        if ctx.author.guild_permissions.manage_messages:
            await ctx.channel.purge(limit=amount)
            await ctx.respond(f"**☑ Success** | Purged {amount} messages")

        else:
            await ctx.respond(f"**☒** | Error: You don't have permission to use this command.")

def setup(bot):
    bot.add_cog(Mod(bot))