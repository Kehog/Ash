import discord
from discord.ext import commands 
import os
import asyncio

bot = commands.Bot(command_prefix="43", intents=discord.Intents.all())

@bot.event
async def on_ready():
   print(f"Logged in as {bot.user}")
   await bot.change_presence(activity=discord.Game(name=f"{len(bot.guilds)} | $help"))

for folder in ["commands", "events"]:
    for file in os.listdir(f"./cogs/{folder}"):
        if file.endswith(".py"):
            try:
                bot.load_extension(f"cogs.{folder}.{file[:-3]}")
                print(f"Loaded {file}")
            except Exception as e:
                print(f"Failed to load extension {file}: {e}")

bot.run("")